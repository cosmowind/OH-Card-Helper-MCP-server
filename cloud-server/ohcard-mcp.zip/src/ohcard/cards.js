// OH卡数据结构 - 从FastMCP迁移
export const OH_CARDS = {
  1: {
    "image_url": "https://cosmowind.github.io/oh-cards/images/card_01.png"
  },
  2: {
    "image_url": "https://cosmowind.github.io/oh-cards/images/card_02.png"
  },
  3: {
    "image_url": "https://cosmowind.github.io/oh-cards/images/card_03.png"
  },
  4: {
    "image_url": "https://cosmowind.github.io/oh-cards/images/card_04.png"
  },
  5: {
    "image_url": "https://cosmowind.github.io/oh-cards/images/card_05.png"
  },
  6: {
    "image_url": "https://cosmowind.github.io/oh-cards/images/card_06.png"
  },
  7: {
    "image_url": "https://cosmowind.github.io/oh-cards/images/card_07.png"
  },
  8: {
    "image_url": "https://cosmowind.github.io/oh-cards/images/card_08.png"
  },
  9: {
    "image_url": "https://cosmowind.github.io/oh-cards/images/card_09.png"
  }
}; 